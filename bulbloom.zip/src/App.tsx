import React, { useState, useEffect } from 'react';
import { auth, db, signIn, signOut } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { collection, query, orderBy, onSnapshot, addDoc, doc, setDoc, getDoc } from 'firebase/firestore';
import { 
  Plus, 
  LayoutDashboard, 
  BookOpen, 
  Target, 
  Brain, 
  LogOut, 
  Github, 
  Heart, 
  MessageSquare, 
  Activity,
  Coffee,
  Languages,
  Linkedin,
  MessageCircle,
  HelpCircle,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { format } from 'date-fns';
import { getAIAdvice, generateLinkedInPost, getMandarinPractice, suggestRestTimes, MandarinQuestion } from './services/aiService';
import { LogEntry, Goal, UserProfile } from './types';

// Google / Flo inspired colors
const COLORS = {
  blue: '#4285F4',
  red: '#EA4335',
  yellow: '#FBBC05',
  green: '#34A853',
  pink: '#FFEDF2',
  softPink: '#FFE4E9',
  indigo: '#6366f1'
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  // Form states
  const [newLog, setNewLog] = useState<Partial<LogEntry>>({
    date: format(new Date(), 'yyyy-MM-dd'),
    learningNotes: '',
    contributionsToGoal: '',
    moduleProgress: { 'Skill 1': 50, 'Skill 2': 50 },
    communicationStatus: 5,
    comprehensionStatus: 5,
    physicalHealth: 5,
    mentalWellbeing: 5,
    restTime: 60,
    journalBody: '',
    relationsStatus: 5
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        fetchData(u.uid);
      }
    });
    return () => unsubscribe();
  }, []);

  const fetchData = async (uid: string) => {
    // Fetch logs
    const logsQuery = query(collection(db, 'users', uid, 'logs'), orderBy('date', 'desc'));
    onSnapshot(logsQuery, (snapshot) => {
      setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LogEntry)));
    });

    // Fetch goals
    const goalsQuery = collection(db, 'users', uid, 'goals');
    onSnapshot(goalsQuery, (snapshot) => {
      setGoals(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Goal)));
    });

    // Fetch profile
    const profileDoc = await getDoc(doc(db, 'users', uid));
    if (profileDoc.exists()) {
      setProfile(profileDoc.data() as UserProfile);
    } else {
      const defaultProfile = { 
        userId: uid, 
        mainGoal: 'My Growth Journey', 
        mandarinLevel: 'Beginner', 
        targetRole: 'Explorer',
        moduleALabel: 'Primary Skill',
        moduleBLabel: 'Secondary Skill'
      };
      setProfile(defaultProfile);
      await setDoc(doc(db, 'users', uid), defaultProfile);
    }
  };

  const handleAddLog = async () => {
    if (!user) return;
    await addDoc(collection(db, 'users', user.uid, 'logs'), {
      ...newLog,
      createdAt: new Date().toISOString()
    });
    setActiveTab('dashboard');
  };

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-[var(--bg-color)]">
        <motion.div 
          animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-12 h-12 bg-[var(--google-blue)] rounded-full shadow-lg shadow-blue-200"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-[var(--bg-color)] p-4">
        <Card className="w-full max-w-md bento-card p-10 bg-white/80 backdrop-blur-md border-none ring-1 ring-black/5">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 bg-[var(--google-blue)] rounded-2xl flex items-center justify-center text-white shadow-xl rotate-3">
                <Brain size={40} className="animate-pulse" />
              </div>
            </div>
            <h1 className="text-4xl font-bold tracking-tighter text-[var(--text-dark)] mb-2">BulBloom</h1>
            <p className="text-[var(--text-muted)] font-medium">Plan, Track, Bloom. Daily.</p>
          </div>
          <Button 
            onClick={signIn} 
            className="w-full h-14 bg-[var(--google-blue)] hover:bg-[#3367d6] text-white rounded-2xl transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-4 text-lg font-bold"
          >
            <Github size={24} />
            Sign in with Google
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-color)] flex flex-col md:flex-row font-sans">
      {/* Sidebar - Desktop */}
      <nav className="w-full md:w-64 bg-white/50 backdrop-blur-sm border-r border-[var(--border)] flex-shrink-0 p-6 space-y-4">
        <div className="flex items-center gap-3 mb-10 px-2 group cursor-default">
          <div className="w-12 h-12 bg-[var(--google-blue)] rounded-2xl flex items-center justify-center text-white shadow-lg transition-transform group-hover:scale-110 group-hover:rotate-6">
            <Brain size={28} />
          </div>
          <span className="font-extrabold text-2xl tracking-tight text-[var(--text-dark)]">BulBloom</span>
        </div>
        
        <div className="space-y-2">
          <NavButton active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} icon={<LayoutDashboard size={22} />} label="Master Dashboard" />
          <NavButton active={activeTab === 'tracking'} onClick={() => setActiveTab('tracking')} icon={<Plus size={22} />} label="Daily Entry" />
          <NavButton active={activeTab === 'goals'} onClick={() => setActiveTab('goals')} icon={<Target size={22} />} label="Goal Mapping" />
          <NavButton active={activeTab === 'coach'} onClick={() => setActiveTab('coach')} icon={<MessageCircle size={22} />} label="AI Architect" />
        </div>
        
        <div className="pt-10 border-t border-[var(--border)] mt-10">
          <button 
            onClick={signOut} 
            className="flex items-center gap-3 px-4 py-3 text-[var(--text-muted)] hover:text-red-500 hover:bg-red-50 rounded-2xl transition-all w-full font-semibold"
          >
            <LogOut size={22} />
            <span>Sign Out</span>
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        <header className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <h2 className="text-4xl font-extrabold tracking-tight text-[var(--text-dark)] mb-1">
              {format(new Date(), 'EEEE, MMM d')}
            </h2>
            <p className="text-[var(--text-muted)] text-lg font-medium">Welcome back, <span className="text-[var(--google-blue)] font-bold">{user.displayName?.split(' ')[0]}</span></p>
          </div>
          <div className="flex items-center gap-4">
             <div className="bg-white px-6 py-2 rounded-2xl text-sm font-bold text-[var(--flo-pink)] border border-[var(--border)] shadow-sm">
               North Star: {profile?.mainGoal || 'Set Goal'}
             </div>
             <div className="bg-[var(--google-blue)] px-6 py-2 rounded-2xl text-xs font-mono text-white shadow-md">
               HSK {profile?.mandarinLevel}
             </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'dashboard' && <Dashboard logs={logs} goals={goals} profile={profile} />}
            {activeTab === 'tracking' && <TrackingForm newLog={newLog} setNewLog={setNewLog} handleAddLog={handleAddLog} profile={profile} />}
            {activeTab === 'goals' && user && <GoalManager goals={goals} user={user} profile={profile} setProfile={setProfile} />}
            {activeTab === 'coach' && <AICoach logs={logs} profile={profile} />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 group ${
        active 
          ? 'bg-[var(--google-blue)] text-white shadow-xl scale-[1.02]' 
          : 'text-[var(--text-muted)] hover:bg-white hover:shadow-md'
      }`}
    >
      <span className={`transition-transform duration-300 ${active ? 'scale-110' : 'group-hover:scale-110'}`}>
        {icon}
      </span>
      <span className="font-bold tracking-tight">{label}</span>
    </button>
  );
}

function Dashboard({ logs, goals, profile }: { logs: LogEntry[], goals: Goal[], profile: UserProfile | null }) {
  const chartData = logs.slice(0, 10).reverse().map(l => ({
    name: format(new Date(l.date), 'MMM d'),
    health: l.physicalHealth,
    mental: l.mentalWellbeing,
    comm: l.communicationStatus,
    comp: l.comprehensionStatus
  }));

  const learningData = logs.slice(0, 10).reverse().map(l => ({
     name: format(new Date(l.date), 'MMM d'),
     skillA: l.moduleProgress[profile?.moduleALabel || 'Skill 1'] || 0,
     skillB: l.moduleProgress[profile?.moduleBLabel || 'Skill 2'] || 0
  }));

  const lastLog = logs[0];

  return (
    <div className="bento-grid grid-rows-[repeat(3,auto)] pb-10">
      {/* Primary Analytics - Span 2 Columns, 2 Rows */}
      <Card className="lg:col-span-2 lg:row-span-2 bento-card border-none overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] flex items-center gap-2">
            <Activity className="text-[var(--google-blue)]" size={16} />
            Holistic Wellbeing Trends
          </CardTitle>
          <CardDescription className="text-[var(--text-muted)]">Visualizing your multi-dimensional life data</CardDescription>
        </CardHeader>
        <CardContent className="h-[350px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorHealth" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.blue} stopOpacity={0.2}/>
                  <stop offset="95%" stopColor={COLORS.blue} stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorMental" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.red} stopOpacity={0.2}/>
                  <stop offset="95%" stopColor={COLORS.red} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="name" fontSize={11} fontWeight={600} tickLine={false} axisLine={false} color="var(--text-muted)" />
              <YAxis domain={[0, 10]} hide />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px -5px rgb(0 0 0 / 0.1)', background: 'white' }}
              />
              <Area type="monotone" dataKey="health" stroke={COLORS.blue} fillOpacity={1} fill="url(#colorHealth)" strokeWidth={4} />
              <Area type="monotone" dataKey="mental" stroke={COLORS.red} fillOpacity={1} fill="url(#colorMental)" strokeWidth={4} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Goal Progress - Column 3, Span 2 Rows */}
      <Card className="lg:col-span-1 lg:row-span-2 bento-card border-none bg-white/60">
        <CardHeader>
          <CardTitle className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] flex items-center gap-2">
            <Target className="text-[var(--google-green)]" size={16} />
            Mission Architect
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          {goals.map((g, i) => (
            <div key={i} className="space-y-3">
              <div className="flex justify-between text-sm font-bold text-[var(--text-dark)]">
                <span className="truncate">{g.title}</span>
                <span className="text-[var(--google-blue)]">{g.progress}%</span>
              </div>
              <div className="h-3 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${g.progress}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full bg-[var(--google-green)] rounded-full"
                />
              </div>
            </div>
          ))}
          {goals.length === 0 && (
             <div className="text-center py-12 text-[var(--text-muted)]">
               <Target size={48} className="mx-auto mb-4 opacity-20" />
               <p className="font-medium">No missions active.</p>
             </div>
          )}
        </CardContent>
      </Card>

      {/* Today's Context - Column 4 */}
      <Card className="lg:col-span-1 bento-card border-none flo-gradient text-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-xs font-bold uppercase tracking-widest opacity-80 flex items-center gap-2 text-white">
             <BookOpen size={16} />
             Current Mastery
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
             <div className="flex items-center justify-between">
                <span className="text-sm font-bold truncate max-w-[150px]">{profile?.moduleALabel || 'Skill 1'}</span>
                <span className="text-2xl font-black">{lastLog?.moduleProgress[profile?.moduleALabel || 'Skill 1'] || 0}%</span>
             </div>
             <div className="flex items-center justify-between">
                <span className="text-sm font-bold truncate max-w-[150px]">{profile?.moduleBLabel || 'Skill 2'}</span>
                <span className="text-2xl font-black">{lastLog?.moduleProgress[profile?.moduleBLabel || 'Skill 2'] || 0}%</span>
             </div>
          </div>
        </CardContent>
      </Card>

      {/* Academic Mastery Graph - Span 2 Columns */}
      <Card className="lg:col-span-2 bento-card border-none">
        <CardHeader className="pb-0">
          <CardTitle className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)] flex items-center gap-2">
            <BookOpen className="text-[var(--google-yellow)]" size={16} />
            Academic Trajectory
          </CardTitle>
        </CardHeader>
        <CardContent className="h-[200px] mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={learningData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
              <XAxis dataKey="name" fontSize={10} fontWeight={600} tickLine={false} axisLine={false} />
              <YAxis hide />
              <Tooltip />
              <Line type="stepAfter" dataKey="skillA" stroke={COLORS.blue} strokeWidth={4} dot={{ r: 4, strokeWidth: 2, fill: 'white' }} />
              <Line type="stepAfter" dataKey="skillB" stroke={COLORS.yellow} strokeWidth={4} dot={{ r: 4, strokeWidth: 2, fill: 'white' }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Mini Stats Grid - Bottom Span 2 */}
      <Card className="lg:col-span-2 bento-card border-none bg-white">
        <CardHeader className="pb-4">
          <CardTitle className="text-xs font-bold uppercase tracking-widest text-[var(--text-muted)]">
            Soft Skills & Vitality
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <DashboardStat label="Comms" value={lastLog?.communicationStatus || 0} icon={<MessageSquare size={16} className="text-[var(--google-blue)]"/>} />
             <DashboardStat label="Reading" value={lastLog?.comprehensionStatus || 0} icon={<BookOpen size={16} className="text-purple-500"/>} />
             <DashboardStat label="Physical" value={lastLog?.physicalHealth || 0} icon={<Activity size={16} className="text-[var(--google-green)]"/>} />
             <DashboardStat label="Mental" value={lastLog?.mentalWellbeing || 0} icon={<Brain size={16} className="text-[var(--flo-pink)]"/>} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DashboardStat({ label, value, icon }: { label: string, value: number, icon: React.ReactNode }) {
  return (
    <div className="bg-[#fafafa] p-4 rounded-3xl border border-[var(--border)] text-center transition-transform hover:scale-105">
      <div className="flex justify-center mb-2">{icon}</div>
      <div className="text-2xl font-black text-[var(--text-dark)]">{value}</div>
      <div className="text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">{label}</div>
    </div>
  );
}

function TrackingForm({ newLog, setNewLog, handleAddLog, profile }: { 
  newLog: Partial<LogEntry>, 
  setNewLog: React.Dispatch<React.SetStateAction<Partial<LogEntry>>>, 
  handleAddLog: () => void,
  profile: UserProfile | null
}) {
  return (
    <div className="max-w-4xl mx-auto space-y-10 pb-20">
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <h3 className="text-2xl font-extrabold flex items-center gap-3 text-[var(--text-dark)]"><BookOpen className="text-[var(--google-blue)]" /> Daily Insights</h3>
          <div className="space-y-4">
             <div className="space-y-2">
               <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)] px-1">Growth Notes</label>
               <Textarea 
                 placeholder="What did you learn or build today?"
                 value={newLog.learningNotes}
                 onChange={(e) => setNewLog({ ...newLog, learningNotes: e.target.value })}
                 className="bento-card bg-white min-h-[140px] border-none shadow-sm focus:ring-2 focus:ring-[var(--google-blue)]"
               />
             </div>
             <div className="space-y-2">
               <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)] px-1">Mission Alignment</label>
               <Textarea 
                 placeholder="How does today contribute to your North Star?"
                 value={newLog.contributionsToGoal}
                 onChange={(e) => setNewLog({ ...newLog, contributionsToGoal: e.target.value })}
                 className="bento-card bg-white min-h-[140px] border-none shadow-sm focus:ring-2 focus:ring-[var(--google-blue)]"
               />
             </div>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-2xl font-extrabold flex items-center gap-3 text-[var(--text-dark)]"><Activity className="text-[var(--google-green)]" /> Performance Metrics</h3>
          <div className="grid grid-cols-1 gap-6">
             <div className="bento-card border-none bg-white p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">{profile?.moduleALabel || 'Skill 1'} Mastery</span>
                  <span className="text-lg font-black text-[var(--google-blue)]">{newLog.moduleProgress?.[profile?.moduleALabel || 'Skill 1'] || 0}%</span>
                </div>
                <Slider 
                  value={[newLog.moduleProgress?.[profile?.moduleALabel || 'Skill 1'] || 0]} 
                  onValueChange={(vals: any) => setNewLog({ ...newLog, moduleProgress: { ...newLog.moduleProgress, [profile?.moduleALabel || 'Skill 1']: vals[0] } })}
                  max={100}
                />
             </div>
             <div className="bento-card border-none bg-white p-6 shadow-sm space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">{profile?.moduleBLabel || 'Skill 2'} Mastery</span>
                  <span className="text-lg font-black text-[var(--google-yellow)]">{newLog.moduleProgress?.[profile?.moduleBLabel || 'Skill 2'] || 0}%</span>
                </div>
                <Slider 
                  value={[newLog.moduleProgress?.[profile?.moduleBLabel || 'Skill 2'] || 0]} 
                  onValueChange={(vals: any) => setNewLog({ ...newLog, moduleProgress: { ...newLog.moduleProgress, [profile?.moduleBLabel || 'Skill 2']: vals[0] } })}
                  max={100}
                />
             </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
             <StatSlider label="Communication" value={newLog.communicationStatus || 0} onChange={(v) => setNewLog({...newLog, communicationStatus: v})} icon={<MessageSquare size={16}/>} color="bg-[var(--google-blue)]" />
             <StatSlider label="Reading Comp" value={newLog.comprehensionStatus || 0} onChange={(v) => setNewLog({...newLog, comprehensionStatus: v})} icon={<BookOpen size={16}/>} color="bg-purple-500" />
             <StatSlider label="Physical Health" value={newLog.physicalHealth || 0} onChange={(v) => setNewLog({...newLog, physicalHealth: v})} icon={<Activity size={16}/>} color="bg-[var(--google-green)]" />
             <StatSlider label="Mental Health" value={newLog.mentalWellbeing || 0} onChange={(v) => setNewLog({...newLog, mentalWellbeing: v})} icon={<Brain size={16}/>} color="bg-[var(--flo-pink)]" />
             <StatSlider label="Relations" value={newLog.relationsStatus || 0} onChange={(v) => setNewLog({...newLog, relationsStatus: v})} icon={<Heart size={16}/>} color="bg-[var(--flo-pink)]" />
             <div className="bento-card border-none bg-white space-y-4 shadow-sm">
               <div className="flex justify-between items-center">
                 <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)] flex items-center gap-2"><Coffee size={14}/> Rest (min)</span>
                 <span className="text-lg font-black text-[var(--google-blue)]">{newLog.restTime}</span>
               </div>
               <Input 
                type="number" 
                value={newLog.restTime} 
                onChange={(e) => setNewLog({...newLog, restTime: parseInt(e.target.value)})}
                className="border-[var(--border)] rounded-xl"
              />
             </div>
          </div>
        </div>
      </section>

      <section className="space-y-6">
        <h3 className="text-2xl font-extrabold flex items-center gap-3 text-[var(--text-dark)]"><MessageCircle className="text-[var(--flo-pink)]" /> The Zenith Journal</h3>
        <Textarea 
          placeholder="Reflect on the architectural details of your day..."
          value={newLog.journalBody}
          onChange={(e) => setNewLog({ ...newLog, journalBody: e.target.value })}
          className="bento-card bg-white min-h-[220px] border-none shadow-sm text-lg"
        />
      </section>

      <div className="flex justify-center pt-10">
        <Button 
          onClick={handleAddLog} 
          className="h-20 px-20 bg-[var(--google-blue)] hover:bg-[#3367d6] rounded-3xl text-2xl font-black shadow-2xl shadow-blue-200 transition-all hover:scale-105 active:scale-95"
        >
           Seal Today's Blueprint
        </Button>
      </div>
    </div>
  );
}

function StatSlider({ label, value, onChange, icon, color }: { label: string, value: number, onChange: (v: number) => void, icon: React.ReactNode, color: string }) {
  return (
    <div className="p-4 bg-white rounded-2xl shadow-sm space-y-4">
      <div className="flex justify-between items-center text-sm font-medium text-gray-700">
        <span className="flex items-center gap-2">{icon} {label}</span>
        <span className="text-lg font-bold">{value}</span>
      </div>
      <Slider value={[value]} onValueChange={(vals: any) => onChange(vals[0])} min={1} max={10} step={1} />
    </div>
  );
}

function GoalManager({ goals, user, profile, setProfile }: { goals: Goal[], user: User, profile: UserProfile | null, setProfile: React.Dispatch<React.SetStateAction<UserProfile | null>> }) {
  const [newTitle, setNewTitle] = useState('');
  
  const addGoal = async () => {
    if (!newTitle) return;
    await addDoc(collection(db, 'users', user.uid, 'goals'), {
      title: newTitle,
      type: 'Professional',
      progress: 0
    });
    setNewTitle('');
  };

  const updateGoal = async (id: string, progress: number) => {
    await setDoc(doc(db, 'users', user.uid, 'goals', id), { progress }, { merge: true });
  };

  const updateProfile = async (field: keyof UserProfile, value: string) => {
    if (!profile) return;
    const newProfile = { ...profile, [field]: value };
    setProfile(newProfile);
    await setDoc(doc(db, 'users', user.uid), newProfile);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 pb-20">
      {/* Profile Settings */}
      <Card className="bento-card border-none bg-white p-8 space-y-6 shadow-xl">
        <h3 className="text-2xl font-black text-[var(--text-dark)]">Identity & Missions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">North Star Goal</label>
            <Input value={profile?.mainGoal} onChange={(e) => updateProfile('mainGoal', e.target.value)} className="rounded-xl border-[var(--border)]" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Mandarin Level</label>
            <Input value={profile?.mandarinLevel} onChange={(e) => updateProfile('mandarinLevel', e.target.value)} className="rounded-xl border-[var(--border)]" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Learning Concentration A</label>
            <Input value={profile?.moduleALabel} onChange={(e) => updateProfile('moduleALabel', e.target.value)} className="rounded-xl border-[var(--border)]" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-muted)]">Learning Concentration B</label>
            <Input value={profile?.moduleBLabel} onChange={(e) => updateProfile('moduleBLabel', e.target.value)} className="rounded-xl border-[var(--border)]" />
          </div>
        </div>
      </Card>

      <div className="flex gap-4 p-4 bento-card border-none bg-white shadow-xl">
        <Input 
          placeholder="New milestone..." 
          value={newTitle} 
          onChange={(e) => setNewTitle(e.target.value)} 
          className="h-14 border-none text-xl font-bold bg-transparent focus:ring-0"
        />
        <Button onClick={addGoal} className="h-14 px-10 bg-[var(--google-blue)] rounded-2xl font-black text-lg">Add Mission</Button>
      </div>
      
      <div className="bento-grid">
        {goals.map((g) => (
          <Card key={g.id} className="bento-card border-none bg-white p-8 space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <h4 className="font-extrabold text-2xl text-[var(--text-dark)] leading-tight">{g.title}</h4>
                <div className="w-16 h-16 rounded-2xl bg-[var(--flo-pink)] flex items-center justify-center text-white text-xl font-black shadow-lg">
                  {g.progress}%
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <Slider 
                value={[g.progress]} 
                onValueChange={(vals: any) => updateGoal(g.id!, vals[0])}
                max={100}
              />
              <div className="flex gap-2">
                <div className="h-2 flex-1 bg-gray-100 rounded-full overflow-hidden">
                   <div className="h-full bg-[var(--google-blue)] transition-all duration-500" style={{ width: `${g.progress}%` }} />
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function AICoach({ logs, profile }: { logs: LogEntry[], profile: UserProfile | null }) {
  const [advice, setAdvice] = useState<{advice: string, bookReference: string} | null>(null);
  const [loadingAdvice, setLoadingAdvice] = useState(false);
  const [linkedinPost, setLinkedinPost] = useState('');
  const [loadingPosts, setLoadingPosts] = useState(false);
  const [mandarinQ, setMandarinQ] = useState<MandarinQuestion | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [restTips, setRestTips] = useState('');

  const fetchAdvice = async () => {
    setLoadingAdvice(true);
    const lastLog = logs[0]?.learningNotes || "No recent history";
    const res = await getAIAdvice(profile?.mainGoal || "Productivity", lastLog);
    setAdvice(res);
    setLoadingAdvice(false);
  };

  const genLinkedIn = async () => {
    setLoadingPosts(true);
    const achievements = logs.slice(0, 3).map(l => l.learningNotes).join(". ");
    const res = await generateLinkedInPost(achievements);
    setLinkedinPost(res);
    setLoadingPosts(false);
  };

  const getMandarin = async () => {
    const res = await getMandarinPractice(profile?.mandarinLevel || 'Beginner');
    setMandarinQ(res);
    setSelectedAnswer(null);
    setIsCorrect(null);
  };

  const checkMandarin = (ans: string) => {
    setSelectedAnswer(ans);
    setIsCorrect(ans === mandarinQ?.correctAnswer);
  };

  const getRest = async () => {
    const history = logs.slice(0, 5).map(l => `Work: ${l.learningNotes}, Rest: ${l.restTime}m`).join("; ");
    const res = await suggestRestTimes(history);
    setRestTips(res);
  };

  return (
    <div className="bento-grid pb-20">
      <Card className="bento-card border-none bg-white p-8 col-span-1 lg:col-span-2">
        <CardHeader className="p-0 mb-6">
          <CardTitle className="text-2xl font-black flex items-center gap-3"><HelpCircle className="text-[var(--google-yellow)]" size={28} /> Wisdom Tap</CardTitle>
          <CardDescription className="text-lg">AI advice synthesized from world-class architecture literature</CardDescription>
        </CardHeader>
        <CardContent className="p-0 space-y-6">
           {advice ? (
             <motion.div 
               initial={{ opacity: 0, scale: 0.95 }}
               animate={{ opacity: 1, scale: 1 }}
               className="space-y-6"
             >
               <p className="text-xl font-medium text-[var(--text-dark)] leading-relaxed italic border-l-8 border-[var(--google-yellow)] pl-8 py-4 bg-[var(--bg-color)] rounded-r-3xl">
                 "{advice.advice}"
               </p>
               <div className="inline-flex items-center gap-3 px-6 py-3 bg-white border border-[var(--border)] rounded-2xl shadow-sm text-[var(--flo-pink)] font-bold">
                 <BookOpen size={20} /> — {advice.bookReference}
               </div>
             </motion.div>
           ) : <p className="text-[var(--text-muted)] text-lg">Your library is silent. Tap to consult the archives.</p>}
           <Button onClick={fetchAdvice} disabled={loadingAdvice} className="w-full h-16 bg-[var(--google-yellow)] hover:bg-[#f9ab00] text-gray-900 rounded-2xl text-lg font-black shadow-lg">
             {loadingAdvice ? "Accessing Core Library..." : "Consult AI Architect"}
           </Button>
        </CardContent>
      </Card>

      <Card className="bento-card border-none bg-[var(--google-blue)] text-white p-8">
        <CardHeader className="p-0 mb-6">
          <CardTitle className="text-2xl font-black flex items-center gap-3 text-white"><Linkedin size={28} /> Brand Architect</CardTitle>
        </CardHeader>
        <CardContent className="p-0 space-y-6">
          <ScrollArea className="h-[200px] p-6 bg-white/10 rounded-3xl text-md font-medium leading-relaxed border border-white/20">
            {linkedinPost || "Convert your daily wins into your next LinkedIn viral post."}
          </ScrollArea>
           <Button onClick={genLinkedIn} disabled={loadingPosts} className="w-full h-16 bg-white text-[var(--google-blue)] hover:bg-gray-100 rounded-2xl text-lg font-black transition-transform active:scale-95 shadow-xl">
             {loadingPosts ? "Generating Narrative..." : "Draft LinkedIn Post"}
           </Button>
        </CardContent>
      </Card>

      <Card className="bento-card border-none bg-white p-8 lg:col-span-1">
        <CardHeader className="p-0 mb-6">
          <CardTitle className="text-2xl font-black flex items-center gap-3"><Languages className="text-[var(--google-green)]" size={28} /> Mandarin Mastery</CardTitle>
          <CardDescription className="font-bold text-[var(--google-green)]">Level: {profile?.mandarinLevel}</CardDescription>
        </CardHeader>
        <CardContent className="p-0 space-y-6">
           {mandarinQ ? (
             <div className="space-y-6">
               <p className="font-black text-2xl text-[var(--text-dark)]">{mandarinQ.question}</p>
               <div className="grid grid-cols-1 gap-3">
                 {mandarinQ.options.map(opt => (
                   <Button 
                    key={opt} 
                    variant={selectedAnswer === opt ? (isCorrect ? 'default' : 'destructive') : 'outline'}
                    onClick={() => checkMandarin(opt)}
                    className={`justify-start text-left h-auto py-5 px-6 rounded-2xl text-md font-bold transition-all ${
                        selectedAnswer === opt ? (isCorrect ? 'bg-[var(--google-green)]' : 'bg-red-500 text-white') : 'border-2 hover:border-[var(--google-green)] hover:text-[var(--google-green)]'
                    }`}
                   >
                     {opt}
                   </Button>
                 ))}
               </div>
               {isCorrect !== null && (
                 <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`text-sm font-bold p-5 rounded-2xl ${isCorrect ? 'bg-green-50 text-[var(--google-green)]' : 'bg-red-50 text-red-500'}`}
                 >
                   {isCorrect ? "✅ Correct Architecture! " : "❌ Structural Error. "} {mandarinQ.explanation}
                 </motion.div>
               )}
             </div>
           ) : <p className="text-[var(--text-muted)] text-lg">Test your linguistics.</p>}
           <Button onClick={getMandarin} className="w-full h-16 bg-[var(--google-green)] hover:bg-[#2e8b44] rounded-2xl text-lg font-black text-white shadow-lg">
             {mandarinQ ? "Next Challenge" : "Start Quiz"}
           </Button>
        </CardContent>
      </Card>

      <Card className="bento-card border-none bg-[#fff5f6] border-2 border-[var(--flo-pink)] p-8">
        <CardHeader className="p-0 mb-6">
          <CardTitle className="text-2xl font-black flex items-center gap-3 text-[var(--flo-pink)]"><Clock size={28} /> Rest Optimization</CardTitle>
        </CardHeader>
        <CardContent className="p-0 space-y-6">
           <div className="h-[200px] p-6 bg-white rounded-3xl text-md font-medium text-[var(--text-muted)] border border-[var(--flo-pink)]/20 scrollbar-hide">
             {restTips || "Optimize your biological cycles for peak building output."}
           </div>
           <Button onClick={getRest} className="w-full h-16 bg-[var(--flo-pink)] hover:bg-[#ff7a8c] text-white rounded-2xl text-lg font-black shadow-lg">
             Suggest Optimal Cycles
           </Button>
        </CardContent>
      </Card>
    </div>
  );
}
