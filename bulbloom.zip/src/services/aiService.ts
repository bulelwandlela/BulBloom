import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
const model = "gemini-3-flash-preview";

export interface AIAdvice {
  advice: string;
  bookReference: string;
}

export interface MandarinQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

export const getAIAdvice = async (topic: string, context: string): Promise<AIAdvice> => {
  const response = await ai.models.generateContent({
    model,
    contents: `Give productivity or life advice on the following topic: "${topic}". 
    Context: ${context}. 
    You MUST reference a real non-fiction book that supports this advice.
    Return JSON with fields: advice (string), bookReference (string).`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          advice: { type: Type.STRING },
          bookReference: { type: Type.STRING }
        },
        required: ["advice", "bookReference"]
      }
    }
  });
  
  return JSON.parse(response.text || "{}");
};

export const generateLinkedInPost = async (achievements: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model,
    contents: `Convert the following daily achievements into a professional LinkedIn post emphasizing growth and learning: ${achievements}. Use a confident yet humble tone.`,
  });
  return response.text || "Failed to generate post.";
};

export const getMandarinPractice = async (level: string): Promise<MandarinQuestion> => {
  const response = await ai.models.generateContent({
    model,
    contents: `Generate a Mandarin Chinese level test question for someone at "${level}" level. 
    Include 4 options. 
    Return JSON with fields: question, options (array of 4 strings), correctAnswer (string matching one option), explanation.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING },
          options: { type: Type.ARRAY, items: { type: Type.STRING } },
          correctAnswer: { type: Type.STRING },
          explanation: { type: Type.STRING }
        },
        required: ["question", "options", "correctAnswer", "explanation"]
      }
    }
  });
  return JSON.parse(response.text || "{}");
};

export const suggestRestTimes = async (workHistory: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model,
    contents: `Based on this work/rest history: ${workHistory}, suggest 3 optimal times for rest during the next 24 hours to maximize productivity. Reference chronotype or productivity research if applicable.`,
  });
  return response.text || "No rest suggestions available.";
};
