export interface Goal {
  id?: string;
  title: string;
  type: 'Professional' | 'Skill' | 'Personal';
  progress: number;
}

export interface LogEntry {
  id?: string;
  date: string;
  learningNotes: string;
  contributionsToGoal: string;
  moduleProgress: {
    NOPS?: number;
    SAD?: number;
    [key: string]: number | undefined;
  };
  communicationStatus: number; // 1-10
  comprehensionStatus: number; // 1-10
  physicalHealth: number; // 1-10
  mentalWellbeing: number; // 1-10
  restTime: number; // minutes
  journalBody: string;
  relationsStatus: number; // 1-10
}

export interface UserProfile {
  userId: string;
  mainGoal: string;
  mandarinLevel: string;
  targetRole: string;
  moduleALabel?: string;
  moduleBLabel?: string;
}
